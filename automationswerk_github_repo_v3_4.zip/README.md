# Automationswerk

KI-Systeme bauen. Prozesse automatisieren. Digitale Umsätze skalieren.

Automationswerk ist eine deutschsprachige Test-/MVP-Website für:
- KI-Automatisierung
- Faceless YouTube
- YouTube Shorts
- Instagram Reels
- TikTok
- Content-OS
- Crossposting
- Analytics
- digitale Umsatzprozesse

## Live-Test mit Vercel

Dieses Repository ist als statische Website vorbereitet.

### Vercel Einstellungen

Framework Preset:
`Other`

Build Command:
leer lassen

Output Directory:
leer lassen

Install Command:
leer lassen

## Lokaler Test

Du kannst die Seite lokal einfach per Browser öffnen:

```bash
open index.html
```

Oder mit einem lokalen Server:

```bash
python -m http.server 3000
```

Dann öffnen:

```text
http://localhost:3000
```

## Wichtige Dateien

```text
index.html
freebie.html
starter-bundle.html
service.html
faceless-youtube-system.html
shorts-reels-tiktok-analytics.html
ki-automatisierung.html
content-automation-setup.html
sitemap.xml
robots.txt
llms.txt
humans.txt
downloads/faceless_youtube_content_os_lite.xlsx
```

## Achtung

Vor aktiver Bewerbung bitte finalisieren:
- Impressum
- Datenschutz
- Checkout-Link
- echte Domain
- Social Links
