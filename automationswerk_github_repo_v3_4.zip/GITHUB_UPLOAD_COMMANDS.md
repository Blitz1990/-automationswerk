# GitHub Upload Commands

## Variante A: GitHub CLI

Im Ordner `automationswerk-github-repo` ausführen:

```bash
git init
git add .
git commit -m "Initial Automationswerk test site"
gh repo create automationswerk --public --source=. --remote=origin --push
```

Für ein privates Repo:

```bash
gh repo create automationswerk --private --source=. --remote=origin --push
```

## Variante B: Manuell über GitHub Web

1. GitHub öffnen.
2. Neues Repository erstellen:
   - Name: `automationswerk`
   - Public oder Private
   - kein README hinzufügen, weil hier schon eins drin ist
3. In das neue Repo gehen.
4. `uploading an existing file` anklicken.
5. Alle Dateien aus diesem Ordner hochladen.
6. Commit message:
   `Initial Automationswerk test site`

## Variante C: Beste Kombination mit Vercel

1. Repo auf GitHub erstellen.
2. In Vercel `Add New Project` klicken.
3. GitHub Repo `automationswerk` importieren.
4. Framework: Other.
5. Deploy.
